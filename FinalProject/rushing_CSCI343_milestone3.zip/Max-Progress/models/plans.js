class Plans{
  constructor(
    id,
    title,
    days,
    weeks
  ){
    this.id=id;
    this.title=title;
    this.days=days;
    this.weeks=weeks;
  }

}

export default Plans;
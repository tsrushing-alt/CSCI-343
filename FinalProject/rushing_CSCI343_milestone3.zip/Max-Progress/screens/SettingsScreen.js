import { Text, View } from "react-native";



export default function SettingsScreen(){
  return(
    <View>
      <Text>This is the Settings Screen</Text>
    </View>
  )
}
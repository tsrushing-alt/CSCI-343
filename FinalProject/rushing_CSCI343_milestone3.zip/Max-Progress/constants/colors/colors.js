const Colors = {
  accent200: "#E0C97F",
  accent500: "#B08A2E",
  accent800: "#8C6D1F",

  primary300o5: "rgba(255, 255, 255, 0.6)",
  primary300: "#ECECEC",
  primary500o8: "rgba(20, 20, 20, 0.8)",
  primary500: "#1A1A1A",
  primary800: "#0D0D0D"
};

export default Colors;

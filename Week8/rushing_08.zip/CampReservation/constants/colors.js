const Colors = {

  accent500: "rgb(42, 70, 50)",        
  accent300: "rgb(95, 130, 90)",      
  primary500: "rgba(214, 123, 49, 1)",    
  primary800: "rgb(138, 54, 17)",    
  primary300: "rgb(235, 222, 198)",    
  primary300o5: "rgba(235, 222, 198, 0.5)",
};

export default Colors;
const Colors = {
  accent500: "#0D3B66",  
  primary300: "#D9E2EC",  
  primary500: "#FFB703",  
  primary800: "#1A1A1A"  
};

export default Colors;